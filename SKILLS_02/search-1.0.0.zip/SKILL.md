---
name: web-search
description: Search the web for real-time information.
---
# web-search

@command(web_search)
Usage: web_search --query <query>
Run: curl -s "https://ddg-api.herokuapp.com/search?q={{query}}"