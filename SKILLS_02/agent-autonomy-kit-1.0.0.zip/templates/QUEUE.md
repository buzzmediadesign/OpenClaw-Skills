# Task Queue

*Last updated: [timestamp]*

---

## 🔴 Ready (can be picked up)

### High Priority
- [ ] [Task description]

### Medium Priority
- [ ] [Task description]

### Low Priority
- [ ] [Task description]

---

## 🟡 In Progress

- [ ] @[agent]: [Task description]

---

## 🔵 Blocked

- [ ] [Task description] (needs: [what's blocking])

---

## ✅ Done Today

- [x] @[agent]: [Task description]

---

## 💡 Ideas (not yet tasks)

- [Idea that might become a task]

---

*Add tasks as you discover them. Pick from Ready when you have capacity.*
